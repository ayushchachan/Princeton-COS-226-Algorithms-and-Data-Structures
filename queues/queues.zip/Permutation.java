import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class Permutation {
    public static void main(String[] args) {
        int k = Integer.parseInt(args[1]);

        RandomizedQueue<String> rq = new RandomizedQueue<>();

        // Do not call 'StdIn.hasNextLine()' in this program. Use 'StdIn.isEmpty()'.
        while (!StdIn.isEmpty()) {
            rq.enqueue(StdIn.readString());
        }

        for (int i = 0; i < k; i++) {
            StdOut.print(rq.dequeue());
        }
    }
}
